package EncapsulationChallenge;

public class Printer {

	private int tonerLevel;
	private int numPagesPrinted;
	private boolean isDuplex;

	public Printer(int tonerLevel, boolean isDuplex) {
		if(tonerLevel > -1 && tonerLevel <= 100) {
			this.tonerLevel = tonerLevel;
		}else {
			this.tonerLevel = -1;
			System.out.println("Toner level can be filled to a maximum of 100%.");
		}

		this.isDuplex = isDuplex;

		this.numPagesPrinted = 0;

	}

	public int addToner(int tonerAmount) {
		if(tonerLevel > 0 && tonerLevel <= 100) {
			if(this.tonerLevel + tonerAmount > 100) {
				return -1;
			}
			this.tonerLevel += tonerAmount;
			return this.tonerLevel;

		}else {
			return -1;
		}


	}

	public int print(int pages) {
		int pagesToPrint = pages;
		if(this.isDuplex) {
			pagesToPrint = (pages / 2) + (pages % 2);
			System.out.println("Printing in duplex mode");
		}
		this.numPagesPrinted += pagesToPrint;
		return pagesToPrint;
	}

	public int getNumPagesPrinted() {
		return numPagesPrinted;
	}






}
